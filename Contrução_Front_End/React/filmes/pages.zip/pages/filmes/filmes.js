import React from 'react'
import Pagina from '../../components/Pagina'

const filmes = () => {
    return (
        <>
            <Pagina titulo="Filmes" />
            <div>filmes</div>
        </>
    )
}

export default filmes